var titles = [];
var categories = [];
var texts = [];
function addPostClick()
{
  window.location.href="edit.html";
}

function addPost()
{
    var table = document.getElementById('postTable');
    var tr = document.createElement('tr');
    tr.id = "1";
    tr.onclick = function() {getClickIndex(this.id);};
    var td = document.createElement('td');
    var button = document.createElement('button');
    button.type = 'button';
    button.name = 'button';
    button.classList.add('Post');
    var div = document.createElement('div');
    div.classList.add('post-content');
    div.align = 'left';
    var h2 = document.createElement('h2');
    h2.innerText = 'Cardano';
    var p = document.createElement('p');
    p.innerHTML = 'ADA is the native token of Cardano and is named after Ada Lovelace, a 19th century mathematician known as the first computer programmer in history. Cardano is a blockchain platform that is used to send and receive digital funds anywhere in the world at increadible speed with tiny fees compare to the traditional banking system.';


    tr.appendChild(td);
    td.appendChild(button);
    button.appendChild(div);
    div.appendChild(h2);
    div.appendChild(p);

    table.appendChild(tr);

    titles.push(h2.innerHTML);
    categories.push(p.innerHTML);
    texts.push("Cardano is also known as ADA.");

    var tr = document.createElement('tr');
    tr.id = "2";
    tr.onclick = function() {getClickIndex(this.id);};
    var td = document.createElement('td');
    var button = document.createElement('button');
    button.type = 'button';
    button.name = 'button';
    button.classList.add('Post');
    var div = document.createElement('div');
    div.classList.add('post-content');
    div.align = 'left';
    var h2 = document.createElement('h2');
    h2.innerText = 'Ethereum';
    var p = document.createElement('p');
    p.innerHTML = 'Vitalik Buterin is the co-founder of Ethereum. (Image: Flickr) Ethereum was conceived by 19-year-old, Russian-Canadian, computer science geek and Bitcoin Magazine writer Vitalik Buterin in November 2013.';


    tr.appendChild(td);
    td.appendChild(button);
    button.appendChild(div);
    div.appendChild(h2);
    div.appendChild(p);

    table.appendChild(tr);

    titles.push(h2.innerHTML);
    categories.push(p.innerHTML);
    texts.push("Vitalik Buterin");

    if (JSON.parse(sessionStorage.getItem("titlePost")) == null)
    {
      sessionStorage.setItem("titlePost", JSON.stringify(titles));
      sessionStorage.setItem("categoryPost", JSON.stringify(categories));
      sessionStorage.setItem("textarea", JSON.stringify(texts));
    }
}

function addMorePosts()
{
  if (JSON.parse(sessionStorage.getItem("titlePost")) != null)
  {
    console.log(JSON.parse(sessionStorage.getItem("titlePost")));
    for (var i = 2; i < JSON.parse(sessionStorage.getItem("titlePost")).length; i++)
    {
      console.log("Ayy");
      var table = document.getElementById("postTable");

      var rowCount = table.rows.length;

      var tr = document.createElement('tr');
      tr.id = (1 + i).toString();
      tr.onclick = function() {getClickIndex(this.id);};
      var td = document.createElement('td');
      var button = document.createElement('button');
      button.type = 'button';
      button.name = 'button';
      button.classList.add('Post');
      var div = document.createElement('div');
      div.classList.add('post-content');
      div.align = 'left';
      var h2 = document.createElement('h2');
      h2.innerText = JSON.parse(sessionStorage.getItem("titlePost"))[i];
      var p = document.createElement('p');
      p.innerHTML = JSON.parse(sessionStorage.getItem("textarea"))[i];

      tr.appendChild(td);
      td.appendChild(button);
      button.appendChild(div);
      div.appendChild(h2);
      div.appendChild(p);

      table.appendChild(tr);
    }
  }
}

// Grabbing the information
function setData()
{
  if (JSON.parse(sessionStorage.getItem("titlePost")) != null)
  {
    var titles = JSON.parse(sessionStorage.getItem("titlePost"));
    var categories = JSON.parse(sessionStorage.getItem("categoryPost"));
    var texts = JSON.parse(sessionStorage.getItem("textarea"));
  }
  var title = document.getElementById("titlePost").value;
  var category = document.getElementById("categoryPost").value;
  var text = tinymce.get("textarea").getContent({format: "text"});


  titles.push(title);
  categories.push(category);
  texts.push(text);

  sessionStorage.setItem("titlePost", JSON.stringify(titles));
  sessionStorage.setItem("categoryPost", JSON.stringify(categories));
  sessionStorage.setItem("textarea", JSON.stringify(texts));

  window.location.href="home.html";
}

function getClickIndex(id)
{
  sessionStorage.setItem("id", id);
  console.log("You clicked " + id);
  window.location.href="details.html";
}

function getClickedID()
{
  console.log("OK");
  var id = sessionStorage.getItem("id");
  var title = document.getElementById("Title");
  var text = document.getElementById("Text");
  var category = document.getElementById("Category");
  var today = new Date();

  var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();

  var dateText = document.getElementById("Date");
  dateText.innerHTML = date;
  console.log(JSON.parse(sessionStorage.getItem("titlePost"))[parseInt(id - 1)]);
  title.innerHTML = JSON.parse(sessionStorage.getItem("titlePost"))[parseInt(id - 1)];
  text.innerHTML = JSON.parse(sessionStorage.getItem("categoryPost"))[parseInt(id - 1)];
  category.innerHTML = JSON.parse(sessionStorage.getItem("textarea"))[parseInt(id - 1)];
}
