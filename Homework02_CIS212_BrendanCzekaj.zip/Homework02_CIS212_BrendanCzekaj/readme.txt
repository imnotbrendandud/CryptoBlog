=================================================
CIS212-Blog Website
=================================================
-I successfully stored the post data using session storage, and
 was able to read and write from that data.

-The website has 2 hard coded posts.

-home.html is the first webpage to go to.

-It took me a lot of time to find solutions to problems, because I am not so
 familiar with javascript. But I have started to get better at it through
 this assignment.